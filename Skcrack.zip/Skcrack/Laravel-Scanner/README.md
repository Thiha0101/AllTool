# Laravel-Scanner
Multi Threaded Laravel scanner for payment gateway merchant key

# Usage
pip install -r requirements.txt

py laravel.py
